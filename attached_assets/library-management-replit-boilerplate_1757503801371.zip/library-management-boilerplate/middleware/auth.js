const jwt = require('jsonwebtoken');

/**
 * Express middleware to verify a JSON Web Token sent in the Authorization header.
 * 
 * If a valid token is provided, the decoded payload is attached to `req.user` and
 * the request proceeds.  Otherwise a 401 response is returned.
 */
module.exports = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  if (!authHeader) {
    return res.status(401).json({ message: 'Authorization header missing' });
  }
  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return res.status(401).json({ message: 'Invalid authorization header format' });
  }
  const token = parts[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
};
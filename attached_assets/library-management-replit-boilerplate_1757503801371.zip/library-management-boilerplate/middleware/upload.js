const multer = require('multer');
const path = require('path');

// Configure storage for Multer.  Files will be stored in the `uploads/` directory.
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

/**
 * Multer instance configured to handle single file uploads.  The field name
 * should be specified when applying the middleware in the route (e.g. `.single('cover')`).
 */
const upload = multer({ storage });

module.exports = upload;
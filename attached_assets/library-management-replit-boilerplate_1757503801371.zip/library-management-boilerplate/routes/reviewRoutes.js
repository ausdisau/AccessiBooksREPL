const express = require('express');
const router = express.Router({ mergeParams: true });

const auth = require('../middleware/auth');
const reviewController = require('../controllers/reviewController');

// The review routes are mounted at /api/books.  Define relative paths here.

// Fetch all reviews for a book (public)
router.get('/:bookId/reviews', reviewController.getReviewsForBook);

// Create a review for a book (protected)
router.post('/:bookId/reviews', auth, reviewController.createReview);

// Update a review (protected)
router.put('/:bookId/reviews/:reviewId', auth, reviewController.updateReview);

// Delete a review (protected)
router.delete('/:bookId/reviews/:reviewId', auth, reviewController.deleteReview);

module.exports = router;
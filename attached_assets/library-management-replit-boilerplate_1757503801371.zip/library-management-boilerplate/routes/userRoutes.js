const express = require('express');
const router = express.Router();

const auth = require('../middleware/auth');
const upload = require('../middleware/upload');
const userController = require('../controllers/userController');

// Registration and login are public
router.post('/register', userController.registerUser);
router.post('/login', userController.loginUser);

// Get all users (protected)
router.get('/', auth, userController.getAllUsers);
router.get('/:id', auth, userController.getUserById);

// Upload profile picture (protected)
router.post('/:id/upload-profile', auth, upload.single('profile'), userController.uploadProfilePicture);

module.exports = router;
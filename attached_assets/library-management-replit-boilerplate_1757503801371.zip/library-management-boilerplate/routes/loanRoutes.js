const express = require('express');
const router = express.Router();

const auth = require('../middleware/auth');
const loanController = require('../controllers/loanController');

// All routes are protected
router.get('/', auth, loanController.getAllLoans);
router.post('/', auth, loanController.createLoan);
router.get('/:id', auth, loanController.getLoanById);
router.put('/:id', auth, loanController.returnLoan);

module.exports = router;
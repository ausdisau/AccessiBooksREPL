const express = require('express');
const router = express.Router();

const auth = require('../middleware/auth');
const authorController = require('../controllers/authorController');

// Public routes
router.get('/', authorController.getAllAuthors);
router.get('/:id', authorController.getAuthorById);

// Protected routes (e.g. only admins can create/update/delete authors)
router.post('/', auth, authorController.createAuthor);
router.put('/:id', auth, authorController.updateAuthor);
router.delete('/:id', auth, authorController.deleteAuthor);

module.exports = router;
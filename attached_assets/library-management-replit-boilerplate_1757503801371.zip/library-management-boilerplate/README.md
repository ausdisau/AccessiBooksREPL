# Library Management System API Boilerplate

This project provides a **starter kit** for building a simple library management system API with **Node.js**, **Express** and **MongoDB (via Mongoose)**.  It includes the basic folder structure, models, controllers, routes and middleware you need to build out a full‑featured REST API.  Most functions are intentionally left as stubs to give you an opportunity to practise implementing the logic yourself.

## Getting Started

1. **Install Dependencies**

   ```bash
   npm install
   ```

2. **Copy the example environment file**

   Create a `.env` file based off of the provided `.env.example` and fill in your MongoDB connection string and JWT secret.

   ```bash
   cp .env.example .env
   # then edit .env
   ```

3. **Start the development server**

   Use the `dev` script to run the server with **Nodemon**:

   ```bash
   npm run dev
   ```

   The API will run on `http://localhost:5000` by default.  You can change the port in the `.env` file.

## Project Structure

```
├── config/             # Database configuration
│   └── db.js           # Connects to MongoDB
├── controllers/        # Route handlers (mostly stubs)
│   ├── authorController.js
│   ├── bookController.js
│   ├── loanController.js
│   ├── reviewController.js
│   └── userController.js
├── middleware/         # Authentication and file upload helpers
│   ├── auth.js         # JWT verification middleware
│   └── upload.js       # Multer configuration for file uploads
├── models/             # Mongoose schemas
│   ├── author.js
│   ├── book.js
│   ├── loan.js
│   ├── review.js
│   └── user.js
├── routes/             # Express routers
│   ├── authorRoutes.js
│   ├── bookRoutes.js
│   ├── loanRoutes.js
│   ├── reviewRoutes.js
│   └── userRoutes.js
├── uploads/            # Where uploaded files (covers/profile pictures) will be stored
├── .env.example        # Sample environment variables
├── .gitignore
├── .replit             # Replit runner config
├── package.json
├── REPLIT_PROMPT.txt   # Challenge instructions (for Replit learners)
└── server.js           # Entry point
```

## What to Build

This boilerplate contains all of the plumbing required to start building a library management API, but the business logic is up to you.  Here are some suggestions:

- **Implement CRUD endpoints** for books, authors, users, loans and reviews using the skeleton controllers and models.
- **Add authentication**: allow users to register and log in, returning a signed JWT.  Protect routes with the provided `auth` middleware.
- **Pagination and filtering**: add support for paging through lists of books and filtering by title, author or category.
- **File uploads**: use the `upload` middleware to allow users to upload book covers and profile pictures.  Store uploaded files in the `uploads/` directory.
- **Validation and error handling**: add appropriate validation and respond with meaningful error messages when input is invalid.

Once you have implemented the features, you can test the endpoints using a REST client such as Postman or Insomnia.  Enjoy building!
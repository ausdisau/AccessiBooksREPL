const mongoose = require('mongoose');

/**
 * Connect to MongoDB using the connection string provided in the environment.
 */
const connectDB = async () => {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    console.warn('MONGO_URI not set in environment. Using default mongodb://localhost:27017/librarydb');
  }
  try {
    await mongoose.connect(uri || 'mongodb://localhost:27017/librarydb');
    console.log('Connected to MongoDB');
  } catch (err) {
    console.error('Failed to connect to MongoDB:', err.message);
    process.exit(1);
  }
};

module.exports = connectDB;
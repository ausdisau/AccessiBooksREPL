const Book = require('../models/book');

/**
 * Get all books.  Accepts optional query parameters for pagination and
 * filtering (e.g. ?title=Harry&author=Rowling).
 */
exports.getAllBooks = async (req, res) => {
  try {
    // TODO: implement pagination and filtering logic
    const books = await Book.find();
    res.json(books);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * Get a single book by its ID.
 */
exports.getBookById = async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) {
      return res.status(404).json({ message: 'Book not found' });
    }
    res.json(book);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * Create a new book.  The request body should contain at least `title` and `author`.
 */
exports.createBook = async (req, res) => {
  try {
    const book = new Book({
      title: req.body.title,
      author: req.body.author,
      category: req.body.category,
      publishedYear: req.body.publishedYear
    });
    const saved = await book.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

/**
 * Update an existing book by ID.  Only fields present in the request body will be updated.
 */
exports.updateBook = async (req, res) => {
  try {
    const updated = await Book.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!updated) {
      return res.status(404).json({ message: 'Book not found' });
    }
    res.json(updated);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

/**
 * Delete a book by ID.
 */
exports.deleteBook = async (req, res) => {
  try {
    const deleted = await Book.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: 'Book not found' });
    }
    res.json({ message: 'Book deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * Upload a cover image for a book.  The file is saved on disk by Multer and the
 * filename is stored on the book document.
 */
exports.uploadBookCover = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }
    const updated = await Book.findByIdAndUpdate(
      req.params.id,
      { coverImage: req.file.filename },
      { new: true }
    );
    if (!updated) {
      return res.status(404).json({ message: 'Book not found' });
    }
    res.json({ message: 'Cover uploaded', book: updated });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
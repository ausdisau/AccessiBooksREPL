const Review = require('../models/review');
const Book = require('../models/book');
const User = require('../models/user');

// Fetch all reviews for a given book ID
exports.getReviewsForBook = async (req, res) => {
  try {
    const bookId = req.params.bookId;
    const reviews = await Review.find({ book: bookId }).populate('user', 'name');
    res.json(reviews);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Create a new review for a book
exports.createReview = async (req, res) => {
  try {
    const { rating, comment, userId } = req.body;
    const bookId = req.params.bookId;
    if (!rating || !userId) {
      return res.status(400).json({ message: 'Rating and user ID are required' });
    }
    const user = await User.findById(userId);
    const book = await Book.findById(bookId);
    if (!user || !book) {
      return res.status(404).json({ message: 'User or book not found' });
    }
    const review = new Review({ book: bookId, user: userId, rating, comment });
    const saved = await review.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Update an existing review
exports.updateReview = async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const updated = await Review.findOneAndUpdate(
      { _id: req.params.reviewId, book: req.params.bookId },
      { rating, comment },
      { new: true }
    );
    if (!updated) {
      return res.status(404).json({ message: 'Review not found' });
    }
    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Delete a review
exports.deleteReview = async (req, res) => {
  try {
    const deleted = await Review.findOneAndDelete({ _id: req.params.reviewId, book: req.params.bookId });
    if (!deleted) {
      return res.status(404).json({ message: 'Review not found' });
    }
    res.json({ message: 'Review deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
const Loan = require('../models/loan');
const Book = require('../models/book');
const User = require('../models/user');

// Get all loans
exports.getAllLoans = async (req, res) => {
  try {
    const loans = await Loan.find().populate('user', 'name email').populate('book', 'title author');
    res.json(loans);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Create a new loan
exports.createLoan = async (req, res) => {
  try {
    const { userId, bookId } = req.body;
    if (!userId || !bookId) {
      return res.status(400).json({ message: 'User ID and book ID are required' });
    }
    const user = await User.findById(userId);
    const book = await Book.findById(bookId);
    if (!user || !book) {
      return res.status(404).json({ message: 'User or book not found' });
    }
    const loan = new Loan({ user: userId, book: bookId });
    const saved = await loan.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get loan by ID
exports.getLoanById = async (req, res) => {
  try {
    const loan = await Loan.findById(req.params.id).populate('user', 'name email').populate('book', 'title author');
    if (!loan) {
      return res.status(404).json({ message: 'Loan not found' });
    }
    res.json(loan);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Mark a loan as returned
exports.returnLoan = async (req, res) => {
  try {
    const loan = await Loan.findById(req.params.id);
    if (!loan) {
      return res.status(404).json({ message: 'Loan not found' });
    }
    loan.returnDate = new Date();
    const saved = await loan.save();
    res.json(saved);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};